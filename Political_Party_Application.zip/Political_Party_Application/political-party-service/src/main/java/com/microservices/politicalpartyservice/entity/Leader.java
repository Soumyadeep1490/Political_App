
package com.microservices.politicalpartyservice.entity;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "lid",
    "pid",
    "lname",
    "lstate"
})
@Generated("jsonschema2pojo")
public class Leader {

    @JsonProperty("lid")
    private Integer lid;
    @JsonProperty("pid")
    private Integer pid;
    @JsonProperty("lname")
    private String lname;
    @JsonProperty("lstate")
    private String lstate;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("lid")
    public Integer getLid() {
        return lid;
    }

    @JsonProperty("lid")
    public void setLid(Integer lid) {
        this.lid = lid;
    }

    @JsonProperty("pid")
    public Integer getPid() {
        return pid;
    }

    @JsonProperty("pid")
    public void setPid(Integer pid) {
        this.pid = pid;
    }

    @JsonProperty("lname")
    public String getLname() {
        return lname;
    }

    @JsonProperty("lname")
    public void setLname(String lname) {
        this.lname = lname;
    }

    @JsonProperty("lstate")
    public String getLstate() {
        return lstate;
    }

    @JsonProperty("lstate")
    public void setLstate(String lstate) {
        this.lstate = lstate;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
