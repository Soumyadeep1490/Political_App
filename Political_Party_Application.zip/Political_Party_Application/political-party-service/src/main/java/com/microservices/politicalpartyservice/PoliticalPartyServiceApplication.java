package com.microservices.politicalpartyservice;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.politicalpartyservice.entity.Leader;

@SpringBootApplication
@RestController
@EnableFeignClients
//@ComponentScan("com.microservices.politicalpartyservice")
public class PoliticalPartyServiceApplication {
	
//	@Autowired
//	private PoliticalLeaderProxy proxy;
	
//	//@PostConstruct
//	@GetMapping("/delete/{lid}")
//	public Leader deleteLeader(@PathVariable("lid") int lid) {
//		Leader leader = 
//		proxy.deleteLeader(lid);
//		return 
//	}

	public static void main(String[] args) {
		SpringApplication.run(PoliticalPartyServiceApplication.class, args);
	}

}
