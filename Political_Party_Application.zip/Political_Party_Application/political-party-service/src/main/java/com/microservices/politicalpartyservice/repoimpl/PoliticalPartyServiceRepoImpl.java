package com.microservices.politicalpartyservice.repoimpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.microservices.politicalpartyservice.entity.PoliticalParties;
import com.microservices.politicalpartyservice.repo.PoliticalPartyServiceRepo;

@Service
@Transactional
public class PoliticalPartyServiceRepoImpl {

	
	private final PoliticalPartyServiceRepo repo;

	@Autowired
	public PoliticalPartyServiceRepoImpl(@Lazy PoliticalPartyServiceRepo repo) {
		this.repo = repo;
	}
	
	//register parties
	public PoliticalParties RegisterParties(PoliticalParties parties) {
		return repo.save(parties);
	}
	
	//get party by id
//	public PoliticalParties findPartyById(Integer pid) {
//		return repo.findPartyById(pid).orElseThrow(() -> new PartyNotFoundException("Party by Id: "+pid+"Not Found"));
//
//	}
	
	//get all
	public List<PoliticalParties> findAllParties(){
		return repo.findAll();
	}
	
}
