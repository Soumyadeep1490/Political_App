package com.microservices.politicalpartyservice.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.microservices.politicalpartyservice.entity.PoliticalParties;

@Repository
@Component
public interface PoliticalPartyServiceRepo extends JpaRepository<PoliticalParties, Integer>{

	//Optional<PoliticalParties> findPartyById(Integer pid);
	
	@Query("SELECT u FROM PoliticalParties u WHERE u.pid = :pid")
	public PoliticalParties findPartyById(@Param("pid") int pid);
	
}
