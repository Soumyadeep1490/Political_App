package com.microservices.politicalpartyservice.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "political_party")
public class PoliticalParties {


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "party_id")
	private int pid;
	
	@NotNull
	@Size(min = 5, max = 100) 
	@Column(name = "party_name")
	private String pname;
	
	@NotNull
	@Size(min = 5, max = 100)
	@Column(name = "party_founder_name")
	private String founder;
	
	@NotNull
	@Column(name = "party_foundation_year")
	private int year;
	
	public PoliticalParties() {
		super();
	}
	
	public PoliticalParties(int pid, String pname, String founder, int year) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.founder = founder;
		this.year = year;
	}
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getFounder() {
		return founder;
	}
	public void setFounder(String founder) {
		this.founder = founder;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	@Override
	public String toString() {
		return "PoliticalParties [pid=" + pid + ", pname=" + pname + ", founder=" + founder + ", year=" + year + "]";
	}
}
