package com.microservices.partywithleaders.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.microservices.partywithleaders.dto.DevelopmentsDto;
import com.microservices.partywithleaders.dto.Leader;
import com.microservices.partywithleaders.dto.PartyWiseLeader;

@FeignClient(url = "localhost:8100", name = "political-leader")
public interface PartyWithLeadersProxy {

	@GetMapping("/all")
	public List<PartyWiseLeader> getParty();
	
	@GetMapping("/leaders/partyLeaders/{pid}")
	public List<Leader> GetLeadersByPartyId(@PathVariable("pid") Integer pid);
	
	@GetMapping("/leaders/allLeaders")
	public List<Leader> getAllLeaders();
	
	@GetMapping("/find/{pid}")
	public PartyWiseLeader findPartyById(@PathVariable("pid") Integer pid);
	
	@GetMapping("/leaders/{lid}/tasks")
	public List<DevelopmentsDto> GetTasksByLeaderId(@PathVariable("lid") Integer lid);
	
	@GetMapping("/leaders/{lid}")
	public Leader GetLeaderById(@PathVariable("lid") Integer lid);
	
}
