
package com.microservices.partywithleaders.dto;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "did",
    "lid",
    "pid",
    "title",
    "activity",
    "budget",
    "state",
    "month",
    "year"
})
@Generated("jsonschema2pojo")
public class DevelopmentsDto {

    @JsonProperty("did")
    private Integer did;
    @JsonProperty("lid")
    private Integer lid;
    @JsonProperty("pid")
    private Integer pid;
    @JsonProperty("title")
    private String title;
    @JsonProperty("activity")
    private String activity;
    @JsonProperty("budget")
    private Double budget;
    @JsonProperty("state")
    private String state;
    @JsonProperty("month")
    private Integer month;
    @JsonProperty("year")
    private Integer year;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("did")
    public Integer getDid() {
        return did;
    }

    @JsonProperty("did")
    public void setDid(Integer did) {
        this.did = did;
    }

    @JsonProperty("lid")
    public Integer getLid() {
        return lid;
    }

    @JsonProperty("lid")
    public void setLid(Integer lid) {
        this.lid = lid;
    }

    @JsonProperty("pid")
    public Integer getPid() {
        return pid;
    }

    @JsonProperty("pid")
    public void setPid(Integer pid) {
        this.pid = pid;
    }

    @JsonProperty("title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(String title) {
        this.title = title;
    }

    @JsonProperty("activity")
    public String getActivity() {
        return activity;
    }

    @JsonProperty("activity")
    public void setActivity(String activity) {
        this.activity = activity;
    }

    @JsonProperty("budget")
    public Double getBudget() {
        return budget;
    }

    @JsonProperty("budget")
    public void setBudget(Double budget) {
        this.budget = budget;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    @JsonProperty("month")
    public Integer getMonth() {
        return month;
    }

    @JsonProperty("month")
    public void setMonth(Integer month) {
        this.month = month;
    }

    @JsonProperty("year")
    public Integer getYear() {
        return year;
    }

    @JsonProperty("year")
    public void setYear(Integer year) {
        this.year = year;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
