package com.microservices.partywithleaders;

import java.awt.print.Printable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.partywithleaders.dto.DevelopmentsDto;
import com.microservices.partywithleaders.dto.Leader;
import com.microservices.partywithleaders.dto.PartyWiseLeader;
import com.microservices.partywithleaders.exception.NotFoundException;
import com.microservices.partywithleaders.proxy.PartyWithLeadersProxy;

@SpringBootApplication
@RestController
@EnableFeignClients
public class PoliticalPartyWithLeadersApplication {

	@Autowired
	private PartyWithLeadersProxy proxy;
	
	@GetMapping("/leader/{lid}/tasks")
	public Leader GetLeaderById(@PathVariable("lid") Integer lid) {
		Leader leader = proxy.GetLeaderById(lid);
		
		List<DevelopmentsDto> tasks = new ArrayList<>();
		tasks = proxy.GetTasksByLeaderId(lid);
		leader.setTasks(tasks);
		
		return leader;
	}
	
	@GetMapping("/party/{pid}/leaders/{lid}/tasks")
	public PartyWiseLeader GetPartyWiseLeadersWithTasks(@PathVariable("pid") Integer pid, 
														@PathVariable("lid") Integer lid) {
		Leader leader = proxy.GetLeaderById(lid);
		List<DevelopmentsDto> tasks = new ArrayList<>();
		tasks = proxy.GetTasksByLeaderId(lid);
		leader.setTasks(tasks);
		
		PartyWiseLeader party = proxy.findPartyById(pid);
		party.setLeader(leader);
		
		return party;
	}

	@GetMapping("/party/{pid}/leaders")
	public PartyWiseLeader findPartyById(@PathVariable("pid") Integer pid) {
		
		PartyWiseLeader party = null;
		
		try {
			party = proxy.findPartyById(pid);
			
			List<Leader> leaderList = new ArrayList<>();
			leaderList = proxy.GetLeadersByPartyId(pid);
			party.setLeaders(leaderList);
			
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}
		
		return party;
		
	}	
	
	public static void main(String[] args) {
		SpringApplication.run(PoliticalPartyWithLeadersApplication.class, args);
	}

}
