package com.microservices.partywithleaders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PoliticalPartyWithLeadersApplicationTests {

	@Test
	void contextLoads() {
	}

}
