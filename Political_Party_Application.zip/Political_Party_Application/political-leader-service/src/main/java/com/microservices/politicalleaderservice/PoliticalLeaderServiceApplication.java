package com.microservices.politicalleaderservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.politicalleaderservice.dto.PoliticalPartiesDto;
import com.microservices.politicalleaderservice.proxy.PoliticalPartyProxy;

@SpringBootApplication
@RestController
@EnableFeignClients
public class PoliticalLeaderServiceApplication {

	@Autowired
	private PoliticalPartyProxy proxy;
	
	@GetMapping("/all")
	public List<PoliticalPartiesDto> getAllParties() {
		return proxy.getParty();
	}
	
	@GetMapping("/find/{pid}")
	public PoliticalPartiesDto findMyParty(@PathVariable("pid") Integer pid) {
		return proxy.getMyParty(pid);
	}
	
	public static void main(String[] args) {
		SpringApplication.run(PoliticalLeaderServiceApplication.class, args);
	}

}
