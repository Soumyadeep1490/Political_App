
package com.microservices.politicalleaderservice.dto;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "pid",
    "pname",
    "founder",
    "year"
})
@Generated("jsonschema2pojo")
public class PoliticalPartiesDto {

    @JsonProperty("pid")
    private Integer pid;
    @JsonProperty("pname")
    private String pname;
    @JsonProperty("founder")
    private String founder;
    @JsonProperty("year")
    private Integer year;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("pid")
    public Integer getPid() {
        return pid;
    }

    @JsonProperty("pid")
    public void setPid(Integer pid) {
        this.pid = pid;
    }

    @JsonProperty("pname")
    public String getPname() {
        return pname;
    }

    @JsonProperty("pname")
    public void setPname(String pname) {
        this.pname = pname;
    }

    @JsonProperty("founder")
    public String getFounder() {
        return founder;
    }

    @JsonProperty("founder")
    public void setFounder(String founder) {
        this.founder = founder;
    }

    @JsonProperty("year")
    public Integer getYear() {
        return year;
    }

    @JsonProperty("year")
    public void setYear(Integer year) {
        this.year = year;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
