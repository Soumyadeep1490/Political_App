package com.microservices.politicalleaderservice.repoimpl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.microservices.politicalleaderservice.entity.DevelopmentEntities;
import com.microservices.politicalleaderservice.entity.PoliticalLeaders;
import com.microservices.politicalleaderservice.repo.DevelopmentRepo;
import com.microservices.politicalleaderservice.repo.PoliticalLeadersServiceRepo;

@Service
@Transactional
public class PoliticalLeadersServiceRepoImpl {
	
//	@Autowired
//	private DevelopmentRepo dRepo;

	private final PoliticalLeadersServiceRepo repo;

	@Autowired
	public PoliticalLeadersServiceRepoImpl(@Lazy PoliticalLeadersServiceRepo repo) {
		super();
		this.repo = repo;
	}
	
//	//assign development tasks
//	public DevelopmentEntities AssignTasks(DevelopmentEntities tasks) {
//		return dRepo.save(tasks);
//	}
	
	//register
	public PoliticalLeaders RegisterLeaders(PoliticalLeaders leaders) {
		return repo.save(leaders);
	}
	
//	//delete
//	public void deleteLeader(int lid) {
//		repo.deleteLeaderById(lid);
//	}
}
