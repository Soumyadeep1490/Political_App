package com.microservices.politicalleaderservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "political_leader")
public class PoliticalLeaders {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "leader_id")
	private int lid;

	@NotNull
	@Column(name = "party_id")
	private int pid;
	
	@NotNull
	@Size(min = 5, max = 100) 
	@Column(name = "leader_name")
	private String lname;
	
	@NotNull
	@Size(min = 5, max = 100) 
	@Column(name = "leader_state")
	private String lstate;
	
	public PoliticalLeaders() {
		super();
	}
	
	public PoliticalLeaders(int lid, int pid, String lname, String lstate) {
		super();
		this.lid = lid;
		this.pid = pid;
		this.lname = lname;
		this.lstate = lstate;
	}
	
	public int getLid() {
		return lid;
	}
	public void setLid(int lid) {
		this.lid = lid;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getLstate() {
		return lstate;
	}
	public void setLstate(String lstate) {
		this.lstate = lstate;
	}
	
	
	
}
