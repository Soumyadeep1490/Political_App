package com.microservices.politicalleaderservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "development")
public class DevelopmentEntities {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "development_id")
	private int did;
	
	@NotNull
	@Column(name = "leader_id")
	private int lid;
	
	@NotNull
	@Column(name = "party_id")
	private int pid;
	
	@Size(min = 5, max = 100)
	@Column(name = "title")
	private String title;
	
	@Size(min = 5, max = 100) 
	@Column(name = "activity")
	private String activity;
	
	@DecimalMax(value = "0.00")
	@Column(name = "budget")
	private Double budget;
	
	@Size(min = 3, max = 50) 
	@Column(name = "state")
	private String state;
	
	@Max(12)
	@Min(1)
	@Column(name = "activity_month")
	private int month;
	
	@Max(2017)
	@Min(2022)
	@Column(name = "activity_year")
	private int year;
	
	public DevelopmentEntities() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public DevelopmentEntities(int did, int lid, int pid, String title, String activity, Double budget, String state,
			int month, int year) {
		super();
		this.did = did;
		this.lid = lid;
		this.pid = pid;
		this.title = title;
		this.activity = activity;
		this.budget = budget;
		this.state = state;
		this.month = month;
		this.year = year;
	}
	
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public int getLid() {
		return lid;
	}
	public void setLid(int lid) {
		this.lid = lid;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public Double getBudget() {
		return budget;
	}
	public void setBudget(Double budget) {
		this.budget = budget;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	
	
}
