package com.microservices.politicalleaderservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.microservices.politicalleaderservice.entity.PoliticalLeaders;

@Repository
public interface PoliticalLeadersServiceRepo extends JpaRepository<PoliticalLeaders, Integer>{

	@Query("SELECT u FROM PoliticalLeaders u WHERE u.lid = :lid")
	public PoliticalLeaders getLeaderById(@Param("lid") int lid);
}
