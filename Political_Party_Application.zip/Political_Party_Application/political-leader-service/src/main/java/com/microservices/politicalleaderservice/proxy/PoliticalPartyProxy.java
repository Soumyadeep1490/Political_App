package com.microservices.politicalleaderservice.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.microservices.politicalleaderservice.dto.PoliticalPartiesDto;

@FeignClient(url = "localhost:8000/parties", name = "political-party")
public interface PoliticalPartyProxy {

	@GetMapping("/all")
	public List<PoliticalPartiesDto> getParty();
	
	@GetMapping("/find/{pid}")
	public PoliticalPartiesDto getMyParty(@PathVariable("pid") Integer pid);
	
}
