package com.microservices.politicalleaderservice.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.politicalleaderservice.entity.DevelopmentEntities;
import com.microservices.politicalleaderservice.entity.PoliticalLeaders;
import com.microservices.politicalleaderservice.exception.NotFoundException;
import com.microservices.politicalleaderservice.repo.DevelopmentRepo;
import com.microservices.politicalleaderservice.repo.PoliticalLeadersServiceRepo;
import com.microservices.politicalleaderservice.repoimpl.PoliticalLeadersServiceRepoImpl;

@RestController
@RequestMapping("/leaders")
public class PoliticalLeadersServiceController {

	private final PoliticalLeadersServiceRepoImpl service;
	
	@Autowired
	private DevelopmentRepo dRepo;
	
	@Autowired
	private PoliticalLeadersServiceRepo repo;

	@Autowired
	public PoliticalLeadersServiceController(PoliticalLeadersServiceRepoImpl service) {
		super();
		this.service = service;
	}
	
	@PostMapping("{lid}/party/{pid}/assignTasks")
	public ResponseEntity<DevelopmentEntities> assignDevelopmentWorks(@RequestBody DevelopmentEntities works, 
																@PathVariable("lid") int lid,
																@PathVariable("pid") int pid){
		DevelopmentEntities tasks = new DevelopmentEntities();

		works.setLid(lid);
		works.setPid(pid);
		tasks = dRepo.save(works);
		
		return new ResponseEntity<DevelopmentEntities>(tasks, HttpStatus.CREATED);
	}
	
	
	@PostMapping("/register/party/{pid}")
	public ResponseEntity<PoliticalLeaders> registerPoliticalLeaders(@RequestBody PoliticalLeaders leaders, @PathVariable("pid") int pid){
		PoliticalLeaders leader = new PoliticalLeaders();
		
		leaders.setPid(pid);
		leader = service.RegisterLeaders(leaders);
		
		return new ResponseEntity<PoliticalLeaders>(leader, HttpStatus.CREATED);
	}
	
	@GetMapping("/allLeaders")
	public List<PoliticalLeaders> getAllLeaders(){
		List<PoliticalLeaders> leaders = repo.findAll();
		return leaders;
	}
	
	@GetMapping("/partyLeaders/{pid}")
	public List<PoliticalLeaders> GetLeadersByPartyId(@PathVariable("pid") int pid){

		List<PoliticalLeaders> leaders = new ArrayList<>();	
		repo.findAll().forEach(l -> leaders.add(l));
		
		List<PoliticalLeaders> leaders1 = new ArrayList<>();	
		for(PoliticalLeaders pl : leaders) {
			if(pl.getPid() == pid) {
				leaders1.add(pl);
			}
		}
		
		return leaders1;
	}
	
	@GetMapping("/{lid}")
	public PoliticalLeaders GetLeaderById(@PathVariable("lid") int lid) {
		
		PoliticalLeaders leader = repo.getLeaderById(lid);
		return leader;
	}
	
	@GetMapping("/{lid}/tasks")
	public List<DevelopmentEntities> GetTasksByLeaderId(@PathVariable("lid") int lid){
		
		List<DevelopmentEntities> tasks = new ArrayList<>();
		dRepo.findAll().forEach(d -> tasks.add(d));
		
		List<DevelopmentEntities> tasks1 = new ArrayList<>();
		for(DevelopmentEntities d1 : tasks) {
			if(d1.getLid() == lid) {
				tasks1.add(d1);
			}
		}
		return tasks1;
	}
	
	@DeleteMapping("/delete/{lid}/party/{pid}")
	public ResponseEntity<?> deleteLeader(@PathVariable("lid") int lid, @PathVariable("pid") int pid) {
		
		PoliticalLeaders leaders = repo.findById(lid)
				.orElseThrow(() -> new NotFoundException("Invalid Leader Id: "+ lid));
		
		if(leaders.getPid() == pid) {
			repo.delete(leaders);
		} else {
			throw new NotFoundException("Invalid Party Id: " + pid);
		}
		

		
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
